# ClassConnect - GitHub Pages Deployment Guide

## 🚀 Quick Setup (5 Minutes)

### Step 1: Create GitHub Repository
1. Go to [github.com](https://github.com)
2. Click **"+"** → **"New repository"**
3. Name: `classconnect`
4. Select **"Public"**
5. ✅ Check **"Add a README file"**
6. Click **"Create repository"**

### Step 2: Upload Files
1. In your repo, click **"Add file"** → **"Upload files"**
2. **Drag and drop** these 2 files:
   - `index.html` (from this zip)
   - `README.md` (from this zip)
3. Click **"Commit changes"**

### Step 3: Enable GitHub Pages
1. Go to **Settings** tab
2. Click **"Pages"** in left sidebar
3. Under **"Source"**, select **"Deploy from a branch"**
4. Select branch: **"main"**
5. Folder: **"/ (root)"**
6. Click **"Save"**

### Step 4: Access Your Site
- Wait 1-2 minutes
- Your site will be live at:
  ```
  https://YOUR-USERNAME.github.io/classconnect/
  ```

---

## ⚙️ Configure Backend URL

### If you have a backend deployed:

1. Open `index.html`
2. Find this line (around line 3815):
   ```javascript
   const API_BASE = 'http://localhost:5000/api';
   ```
3. Change it to your backend URL:
   ```javascript
   const API_BASE = 'https://your-backend-url.com/api';
   ```
4. Commit the changes

### If you don't have a backend yet:

The app will show "Failed to fetch" errors when trying to login/signup.

**To get a backend:**
- Use Railway.app (free tier available)
- Deploy the backend code from `backend-for-github.zip`
- Copy the Railway URL and update `API_BASE`

---

## 🔐 Demo Accounts (When Backend is Connected)

| Role | Email | Password |
|------|-------|----------|
| Admin | `admin@school.edu` | `admin123` |
| Teacher | `teacher@school.edu` | `teacher123` |
| Student | `student@student.edu` | `student123` |

---

## 🐛 Troubleshooting

### Page shows 404
- Make sure `index.html` is in the **root** folder (not in a subfolder)
- Check that GitHub Pages is enabled in Settings → Pages
- Wait 2-3 minutes after enabling

### Login shows "Failed to fetch"
- Backend is not configured or not running
- Check `API_BASE` URL in `index.html`
- Make sure backend is deployed and accessible

### Styles not loading
- Hard refresh: `Ctrl + Shift + R` (Windows) or `Cmd + Shift + R` (Mac)
- Clear browser cache

---

## 📁 File Structure

```
classconnect/
├── index.html          # Main application file
└── README.md          # This file
```

That's it! Just 2 files needed.

---

## 🎯 Next Steps

1. ✅ Deploy frontend to GitHub Pages (you're here!)
2. ⏳ Deploy backend to Railway.app
3. ⏳ Update `API_BASE` in `index.html`
4. ⏳ Test login/signup
5. ⏳ Start using ClassConnect!

---

**Need the backend code?** Download `backend-for-github.zip` separately.
